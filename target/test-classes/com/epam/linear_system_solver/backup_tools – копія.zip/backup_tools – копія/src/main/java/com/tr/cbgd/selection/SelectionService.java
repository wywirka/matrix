package com.tr.cbgd.selection;

import com.tr.cbgd.backup.InstanceBackup;
import com.tr.cbgd.backup.InstanceInfo;
import com.tr.cbgd.common.HDFSManager;
import com.tr.cbgd.common.HbaseManager;
import com.tr.cbgd.config.HbaseProperties;
import com.tr.cbgd.config.HdfsProperties;
import lombok.extern.slf4j.Slf4j;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hbase.protobuf.generated.HBaseProtos;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.function.Predicate;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static java.util.stream.Collectors.groupingBy;

@Slf4j
public class SelectionService {

    private HbaseManager dbManager;
    private HDFSManager dfsManager;
    private HdfsProperties dfsProps;
    private HbaseProperties dbProps;

    public SelectionService(HbaseManager dbManager, HDFSManager dfsManager, HdfsProperties dfsProps, HbaseProperties dbProps) {
        this.dbManager = dbManager;
        this.dfsManager = dfsManager;
        this.dfsProps = dfsProps;
        this.dbProps = dbProps;
    }

    public List<InstanceBackup> createForVerification(Predicate<String>  rawPredicate, Predicate<String> snapshotPredicate, Pattern grPattern) throws IOException, NoSuchFieldException, IllegalAccessException {
        List<InstanceInfo> metadata = dbManager.readTable(dbProps.getInstancesTable()).stream().filter(r -> rawPredicate.test(r.getId())).collect(Collectors.toList());
        for(InstanceInfo ii: metadata){
            System.out.println(ii);
        }
        Map<String, List<HBaseProtos.SnapshotDescription>> hbaseSnapshots = selectHbSnaps(snapshotPredicate, grPattern);
        Optional<Path> snapshotPath = selectHdfsPath();
        List<InstanceBackup> instances = new ArrayList<>();
         for(InstanceInfo md: metadata){
            String instance = md.getId();
            List<HBaseProtos.SnapshotDescription> snaps = hbaseSnapshots.get(instance);
            Path snapPath = snapshotPath.isPresent()? snapshotPath.get() : null;
            Path instancePath = null;
            if(snapPath != null){
                instancePath = dfsManager.checkPath(new Path(snapPath,"instances/" + instance)) ? new Path(snapPath,"instances/" + instance) : null;
            }
            if(snaps == null || snapPath == null || instancePath == null ){
                log.warn(" Instance {} is not valid ", instance);
            }
            else{
                long tm = snaps.get(0).getCreationTime();
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                String date  = dateFormat.format(tm);
                instances.add(new InstanceBackup(instance, date, md.getFirmId(), snaps, instancePath ));
            }
        }
         return instances;
    }

    public static String find(String str, Pattern pattern){
        Matcher m = pattern.matcher(str);
        m.find();
        return m.group(1);

    }

    public  Map<String, List<HBaseProtos.SnapshotDescription>> selectHbSnaps(Predicate<String> filterPredicate, Pattern groupPattern) throws IOException{
        return dbManager.listSnapshots().stream().filter(s -> filterPredicate.test(s.getName())).collect(groupingBy(g -> find(g.getName(), groupPattern )));
    }

    public Optional<Path> selectHdfsPath() throws IOException{
        String strDate = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
        return dfsManager.listFiles(dfsProps.getSnapshotPath()).stream().filter(l -> l.getPath().getName().contains(strDate)).map(s -> s.getPath()).findFirst();
    }
}
