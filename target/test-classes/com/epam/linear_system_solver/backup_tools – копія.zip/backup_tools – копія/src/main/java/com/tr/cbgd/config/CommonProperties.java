package com.tr.cbgd.config;

import org.apache.hadoop.fs.Path;

import java.io.File;

public class CommonProperties {
    private String hbaseSite;
    private String coreSite;
    private String hdfsSite;
    private String hadoopUser;
    private String krb5File;
    private String keyTab;
    private String jaasFile;
    private int retentionDays;
    private HbaseProperties hbaseProperties;
    private HdfsProperties hdfsProperties;

    public Path getHbaseSite() {
        return new Path(hbaseSite);
    }

    public Path getCoreSite() {
        return new Path(coreSite);
    }

    public Path getHdfsSite() {
        return new Path(hdfsSite);
    }

    public String getHadoopUser() {
        return hadoopUser;
    }

    public String getKrb5File() {
        return new File(krb5File).getAbsolutePath();
    }

    public String getKeyTab() {
        return new File(keyTab).getAbsolutePath();
    }

    public String getJaasFile() {
        return new File(jaasFile).getAbsolutePath();
    }

    public int getRetentionDays() { return retentionDays; }

    public HbaseProperties getHbaseProperties() {
        return hbaseProperties;
    }

    public HdfsProperties getHdfsProperties() {
        return hdfsProperties;
    }


}
