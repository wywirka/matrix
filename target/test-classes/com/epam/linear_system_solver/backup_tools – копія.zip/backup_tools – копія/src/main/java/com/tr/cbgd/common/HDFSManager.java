package com.tr.cbgd.common;

import com.tr.cbgd.config.HdfsProperties;
import lombok.extern.slf4j.Slf4j;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.*;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
public class HDFSManager {

    private Configuration conf;
    private FileSystem dfs;
    private PathHandler handler;
    private Path originalPath;
    private Path tempPath;


    public HDFSManager(Configuration conf, FileSystem dfs, PathHandler handler, HdfsProperties fsProps) {
        this.conf = conf;
        this.dfs = dfs;
        this.handler = handler;
        this.originalPath = fsProps.getOriginalPath();
        this.tempPath = fsProps.getTempPath();
    }





    private Set<String> filesToSet(Path fullPath) throws IOException{
        Set<String> relPathSet = new HashSet();
        Path parent = fullPath.getParent();
        log.info("Parent folder {}", parent);
        int len = parent.toString().length();
        RemoteIterator<LocatedFileStatus> rmIterator = dfs.listFiles(fullPath, true);
        while(rmIterator.hasNext()){
            FileStatus item = rmIterator.next();
            String relPath = toRelative(item.getPath(), len);
            log.info(relPath);
            relPathSet.add(relPath);
        }
        return relPathSet;
    }

//    private String toRelative(Path absPath, Path base){
//        log.info("Abs path {}",absPath.toString());
//        log.info("Base path {}",base.toString());
//        Path newAbs = new Path (absPath.toString().replace(dfs.getUri().toString(),""));
//        log.info("New Abs path {}", newAbs);
//        log.info("Relative {}", base.toUri().relativize(absPath.toUri()).getPath());
//        return base.toUri().relativize(newAbs.toUri()).getPath();
//    }


    private String toRelative(Path absPath, int start){
        log.info("Abs path {}",absPath.toString());
        log.info("REl path {}", absPath.toString().substring(start+1));
        return absPath.toString().substring(start+1);
    }

    public boolean checkPath(Path p) throws IOException {
        return dfs.exists(p);
    }


    public List<FileStatus> listFiles(Path path) throws IOException {
        return Arrays.asList( dfs.listStatus(path));
    }


    public boolean delete(Path path) throws IOException{
        log.info("Path {} is deleting", path);
        return  dfs.delete(path,true);
    }


    public Path copyToNew(Path src, Path dst) throws IOException{
        if(!checkPath(dst)){
//      ??  is better to make dir or not
            log.error("A destination folder {} wasn't found", dst);
            throw new FileNotFoundException(src + " folder wasn't found");
        }
        boolean isCopied = FileUtil.copy(dfs, src, dfs, dst, false, conf);
        if(!isCopied){
            log.error("Making copy of {} failed", src);
            throw new IOException("Copy operation failed");
        }
        log.info("Directory {} has been copied successfully to {}", src, dst);
        return new Path(dst, src.getName());
    }


    public void restoreFromSnapshot(Path instanceSnapshot) throws IOException {
//        TODO originalPath path for any folder
        String instanceName = instanceSnapshot.getName();
        Path instancePath = new Path(originalPath, instanceName);
        if (dfs.exists(instancePath)) {
            Path backupPath = new Path(originalPath, handler.generateFileName(instanceName));
//            do I need to handle rename output ?
            dfs.rename(instancePath, backupPath);
            log.info("Original path {}  has been renamed to {}", instancePath, backupPath);
            copyToNew(instanceSnapshot, originalPath);
            log.info("Snapshot {} has been restored", instanceSnapshot);
//            move to rollback part ?
            delete(backupPath);
        } else {
            copyToNew(instanceSnapshot, originalPath);
            log.info("Snapshot {} has been restored", instanceSnapshot);

        }
    }

    public String checkFilesIdentity(Path path1, Path path2) throws IOException {
        StringBuilder messageBuilder = new StringBuilder();
        try{
            Set<String> fileSet1 = filesToSet(path1);
            Set<String> fileSet2 = filesToSet(path2);
            List<String> commonFiles = handler.fileIntersection(fileSet1, fileSet2);
            if (fileSet1.size() == fileSet2.size() && fileSet1.size() == commonFiles.size()) {
                for (String relFilePath : commonFiles) {
                    if (!isIdentical(relFilePath, originalPath, tempPath)) {
                        messageBuilder.append(relFilePath).append(", ");
                    }
                }
                messageBuilder.append(" found as not identical");
            }
            else{
                messageBuilder.append("Difference in files between locations: ")
                        .append(handler.fileSymDifference(fileSet1, fileSet2).stream().collect(Collectors.joining(",")));
            }
        }catch (IOException e){
            e.printStackTrace();
            log.error("identity can't be checked");
            throw new IOException("identity can't be checked");
        }
        return messageBuilder.toString();
    }



    private boolean isIdentical(String relPath, Path base1, Path base2) throws IOException{
//            dfs.getFileChecksum(file1).equals(dfs.getFileChecksum(file2));
//            File checksum issue: identical not-empty files don't have identical checksums
//            there was decided to use file size to check file identity
        Path file1 = new Path(base1, relPath);
        Path file2 = new Path(base2, relPath);
        return dfs.getFileStatus(file1).getLen() == dfs.getFileStatus(file2).getLen();
    }
}
