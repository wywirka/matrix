package com.tr.cbgd.config;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;

public class ArgumentValidator {

    public static boolean check(String param){
        return StringUtils.isEmpty(param);
    }

    public static int parsePriorDays(String param, int retentionValue){
        int index;
        if(param.equalsIgnoreCase("latest")){
            return 0;
        }
        index = Integer.parseInt(param);
        if(index >= retentionValue){
            return index;
        }
        throw new IllegalArgumentException("Days extend retention policy");
    }
}
