package com.tr.cbgd.config;

public class HbaseProperties {

    private static String HB_NAMESPACE_DELIMITER = ":";

    private String namespace;
    private String instancesTable;
    private String verificationTable;
    private String posfix;

    public String getNamespace() {
        return namespace;
    }

    public String getInstancesTable() {
        return this.namespace + HB_NAMESPACE_DELIMITER + this.instancesTable;
    }

    public String getVerificationTable() {
        return verificationTable;
    }

    public String getPosfix() {
        return posfix;
    }
}
