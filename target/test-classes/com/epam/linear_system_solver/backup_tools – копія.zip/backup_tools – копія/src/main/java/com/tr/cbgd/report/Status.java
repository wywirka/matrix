package com.tr.cbgd.report;

public enum Status {
    VALID,
    INVALID,
    UNKNOWN
}
