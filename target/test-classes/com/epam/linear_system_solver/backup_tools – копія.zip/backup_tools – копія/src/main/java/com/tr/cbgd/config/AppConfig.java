package com.tr.cbgd.config;

import lombok.extern.slf4j.Slf4j;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.security.UserGroupInformation;

import java.io.IOException;

import static org.apache.hadoop.security.UserGroupInformation.*;

@Slf4j
public class AppConfig {

//    public static Path HBASE_SITE = new Path("/usr/lib/hbase/conf/hbase-site.xml");
//    public static Path CORE_SITE = new Path("/usr/lib/hbase/conf/core-site.xml");
//    public static Path HDFS_SITE = new Path("/usr/lib/hbase/conf/hdfs-site.xml");

    public static Path HBASE_SITE = new Path("C:\\Users\\Iryna_Tymochko\\IdeaProjects\\hbase-verification\\etc\\dev2\\hbase-conf\\hbase-site.xml");
    public static Path CORE_SITE = new Path("C:\\Users\\Iryna_Tymochko\\IdeaProjects\\hbase-verification\\etc\\dev2\\hbase-conf\\core-site.xml");
    public static Path HDFS_SITE = new Path("C:\\Users\\Iryna_Tymochko\\IdeaProjects\\hbase-verification\\etc\\dev2\\hbase-conf\\hdfs-site.xml");

    public static Configuration getConfig(CommonProperties commonConf){

        System.setProperty("java.security.krb5.conf", commonConf.getKrb5File());
        System.setProperty("java.security.auth.login.config", commonConf.getJaasFile());
//        System.setProperty("java.security.krb5.conf", new File(" /etc/krb5.conf").getAbsolutePath());
//        System.setProperty("java.security.auth.login.config", new File("/usr/lib/hbase/conf/jaas.conf").getAbsolutePath());

//        System.setProperty("java.security.krb5.conf", new File("C:\\Users\\Iryna_Tymochko\\IdeaProjects\\hbase-verification\\etc\\dev2\\krb5.conf").getAbsolutePath());
//        System.setProperty("java.security.auth.login.config", new File("C:\\Users\\Iryna_Tymochko\\IdeaProjects\\hbase-verification\\etc\\dev2\\jaas.conf").getAbsolutePath());
        Configuration config = HBaseConfiguration.create();
//        config.addResource(HBASE_SITE);
//        config.addResource(HDFS_SITE);
//        config.addResource(CORE_SITE);

//        config.set("hadoop.security.authentication", "kerberos");
//        config.set("hbase.security.authentication", "kerberos");



        config.addResource(commonConf.getHbaseSite());
        config.addResource(commonConf.getCoreSite());
        config.addResource(commonConf.getHdfsSite());
//        config.set("dfs.checksum.combine.mode", "COMPOSITE_CRC");
        log.info("Xml sites have been added to configs");
        return config;
    }

    public static UserGroupInformation getUserGroupInformation(final Configuration config, CommonProperties cp) throws IOException {
        setConfiguration(config);
//        String keyTab = new File("/appserver/kerberos_keytab/ooxp.keytab").getAbsolutePath();
//        String keyTab = new File("C:\\Users\\Iryna_Tymochko\\IdeaProjects\\hbase-verification\\etc\\dev2\\ooxp.keytab").getAbsolutePath();
        String keyTab = cp.getKeyTab();
        loginUserFromKeytab(cp.getHadoopUser(), keyTab);

        return loginUserFromKeytabAndReturnUGI(cp.getHadoopUser(), keyTab);
    }
}