package com.tr.cbgd.backup;

import java.util.function.Predicate;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class FilterCondition {


    public static Predicate<String> isSuitable(Pattern snapshotPattern){
        return line -> line.contains("2020-09-10") && match(line, snapshotPattern);
    }

    public static Predicate<String> isRequested(Pattern userPattern){
        return line -> match(line, userPattern);
    }

    public static boolean match(String text, Pattern pattern){
        return pattern.matcher(text).matches();
    }
}
