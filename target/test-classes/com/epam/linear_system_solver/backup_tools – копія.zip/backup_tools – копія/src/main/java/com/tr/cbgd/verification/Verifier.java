package com.tr.cbgd.verification;

import com.tr.cbgd.backup.InstanceBackup;
import com.tr.cbgd.report.Status;
import com.tr.cbgd.report.VerificationReport;

public abstract class Verifier {
    protected Verifier next;

    public abstract CheckingResult verifyItem(InstanceBackup ins);

    public  VerificationReport verify(InstanceBackup ins){
        CheckingResult checking = verifyItem(ins);
        if (hasNext() && checking.getStatus() == Status.VALID ){
            return next.verify(ins);
        }
        return VerificationReport.generate(ins, checking);
    }


    public Verifier setNext(Verifier verifier){
        this.next = verifier;
        return next;

    }

    public boolean hasNext(){
        return next != null;
    }

}
