package com.tr.cbgd.report;


import com.tr.cbgd.backup.InstanceBackup;
import com.tr.cbgd.verification.CheckingResult;

public class VerificationReport {

    private String name;
    @Column(columnFamily = "info", qualifier ="instance")
    private String instance;
    @FromEnum
    @Column(columnFamily = "info", qualifier ="status")
    private Status status;
    @Column(columnFamily = "info", qualifier ="message")
    private String message;

    public VerificationReport() {
    }


    public VerificationReport(String name, String instance, Status status) {
        this.name = name;
        this.instance = instance;
        this.status = status;
    }

    public VerificationReport(String name, String instance, Status status, String message) {
        this.name = name;
        this.instance = instance;
        this.status = status;
        this.message = message;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getName() {
        return name;
    }

    public Status getStatus() {
        return status;
    }

    public String getMessage() {
        return message;
    }


    public static VerificationReport generate(InstanceBackup ins, CheckingResult result){
        return  new VerificationReport(ins.getName() +"_"+ ins.getDate(), ins.getName(), result.getStatus(), result.getMessage());

    }

    @Override
    public String toString() {
        return "Report: " +
                "='" + name + '\'' +
                "with status " + status + '\'' +
                ", message='" + message + '\'' +
                ", for instance " + instance + '\'' +
                '}';
    }
}
