package com.tr.cbgd.backup;

public class InstanceInfo {
    private String id;
    private String firmId;

//    public InstanceMetadata(String id, String firmId) {
//        this.id = id;
//        this.firmId = firmId;
//    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getFirmId() {
        return firmId;
    }

    public void setFirmId(String firmId) {
        this.firmId = firmId;
    }

    @Override
    public String toString() {
        return "InstanceMetadata{" +
                "id='" + id + '\'' +
                ", firmId='" + firmId + '\'' +
                '}';
    }
}
