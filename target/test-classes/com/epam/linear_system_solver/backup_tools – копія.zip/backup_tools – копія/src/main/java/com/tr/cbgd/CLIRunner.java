package com.tr.cbgd;//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;

import com.tr.cbgd.backup.FilterCondition;
import com.tr.cbgd.common.HbaseManager;
import com.tr.cbgd.selection.SelectionService;
import com.tr.cbgd.backup.InstanceBackup;
import com.tr.cbgd.common.HDFSManager;
import com.tr.cbgd.common.PathHandler;
import com.tr.cbgd.config.*;
import com.tr.cbgd.report.ConsoleResultHandler;
import com.tr.cbgd.report.HbaseResultHandler;
import com.tr.cbgd.report.ReportHandler;
import com.tr.cbgd.report.VerificationReport;
import com.tr.cbgd.verification.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.hbase.client.Admin;
import org.apache.hadoop.hbase.client.Connection;
import org.apache.hadoop.hbase.client.ConnectionFactory;
import org.apache.hadoop.security.UserGroupInformation;

import java.io.IOException;
import java.security.PrivilegedExceptionAction;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;


@Slf4j
public class CLIRunner {

    public static void main(String[] args) throws IOException, InterruptedException, NoSuchFieldException, IllegalAccessException {

        run(args);

    }

    public static void run(String[] args) throws IOException, InterruptedException, NoSuchFieldException, IllegalAccessException{
//        Configuration configs =  AppConfig.getConfig();
////        Connection connection = ConnectionFactory.createConnection(configs);
////        Admin admin = connection.getAdmin();
//        FileSystem dfs = FileSystem.get(configs);
//        PathHandler pathHandler = new PathHandler(BASE_DIR, TEMP_DIR);
////        HbaseManager bdManager = new HbaseManager(configs, connection, admin, dfs);
//        HDFSManager dfsManager = new HDFSManager(configs, dfs, pathHandler);
//        Path p = dfsManager.copyToNew(new Path("/tmp"), new Path("/tr"));
//        System.out.println(p);
//        String action = args[0];
//        String instance = args[1];
//        String type = args[2];

//        List<HBaseProtos.SnapshotDescription> dbSnaps = bdManager.listSnapshots().stream()
//                .filter(s -> s.getName().contains(instance) && s.getName()
//                .contains(LATEST_DATE)).collect(Collectors.toList());
//
//        Path insPath = new Path(SNAPSHOT_PATH, instance);
//        Instance inst = new Instance(instance, LATEST_DATE, dbSnaps, insPath);
//
//        if(action.equals("verify")){
//            VerifyService verService = new VerifyService(bdManager, dfsManager);
//            Verifier mdVerifier = new MetadataVerifier(verService);
//            Verifier rcVerifier = new RowVerifier(verService);
//            Verifier flVerifier = new FileVerifier(verService);
//            List<VerificationReport> reports = new ArrayList<>();
//            VerificationReport report;
//            if(type.equals("brief")){
//                mdVerifier.setNext(flVerifier);
//                report =  mdVerifier.verify(inst);
//            }
//            else{
//                mdVerifier.setNext(rcVerifier);
//                rcVerifier.setNext(flVerifier);
//                report = mdVerifier.verify(inst);
//            }
//            reports.add(report);
//            ReportHandler dbHandler = new HbaseResultHandler(bdManager, TABLE_NAME);
//            ReportHandler cnsHandler = new ConsoleResultHandler();
//            dbHandler.setNext(cnsHandler);
//            dbHandler.handle(reports);
//        }
//        else if(action.equals("restore")){
//
//            RestoreService rsService = new RestoreService(bdManager, dfsManager);
////            rsService.run();
//        }
//        else{
//            System.out.println("Wrong action");
//        }


//        String instancePattern = "ooxp-v9m-s.*";

        CommonProperties commonProps = ConfigParser.parse("src/main/resources/app-local.yaml");
        HbaseProperties hbProps = commonProps.getHbaseProperties();
        HdfsProperties hdfsProps = commonProps.getHdfsProperties();
        PathHandler pathHandler = new PathHandler();
        int priorDays;
        String action = args[0];
        String instancePattern = args[1];
        if(StringUtils.isEmpty(action)){
            throw new IllegalArgumentException("Action argument can't be empty");
        }
        if(StringUtils.isEmpty(instancePattern)){
            throw new IllegalArgumentException("Instance argument can't be empty");
        }


        Configuration configs =  AppConfig.getConfig(commonProps);
        UserGroupInformation ui = AppConfig.getUserGroupInformation(configs, commonProps);
        FileSystem dfs = (FileSystem) ui.doAs((PrivilegedExceptionAction<Object>) () -> FileSystem.get(configs));
        Connection connection = (Connection) ui.doAs((PrivilegedExceptionAction<Object>) () -> ConnectionFactory.createConnection(configs));
        Admin admin = connection.getAdmin();

        HbaseManager bdManager = new HbaseManager(configs, connection, admin, dfs);
        HDFSManager dfsManager = new HDFSManager(configs, dfs, pathHandler,hdfsProps);


        if(action.equalsIgnoreCase("verify")){
            SelectionService insManager = new SelectionService(bdManager, dfsManager, hdfsProps, hbProps);
            String  snapshotPattern = ".*"+ commonProps.getHbaseProperties().getNamespace() +"\\." + instancePattern + commonProps.getHbaseProperties().getPosfix() +".*";
            log.info("Instance pattern {}", instancePattern);
            log.info("Snapshot pattern {}", snapshotPattern);
            List<InstanceBackup> backups = insManager.createForVerification(FilterCondition.isRequested(Pattern.compile(instancePattern)), FilterCondition.isSuitable(Pattern.compile(snapshotPattern)), Pattern.compile("\\.(ooxp.*)_.*") );
            VerifyService verService = new VerifyService(bdManager, dfsManager, hbProps, hdfsProps);
            Verifier mdVerifier = new MetadataVerifier(verService);
            Verifier rcVerifier = new RowVerifier(verService);
            Verifier flVerifier = new FileVerifier(verService);
            List<VerificationReport> reports = new ArrayList<>();
            mdVerifier.setNext(flVerifier);
//        rcVerifier.setNext(flVerifier);
            ReportHandler dbHandler = new HbaseResultHandler(bdManager, hbProps.getVerificationTable());
            ReportHandler cnsHandler = new ConsoleResultHandler();
            dbHandler.setNext(cnsHandler);

            for(InstanceBackup inst : backups){
                System.out.println(inst);
                VerificationReport report = mdVerifier.verify(inst);
                reports.add(report);
            }

            dbHandler.handle(reports);
        }

        else if(action.equalsIgnoreCase("restore")){
            priorDays = ArgumentValidator.parsePriorDays(args[2], commonProps.getRetentionDays());
        }

        else{
            log.error("Action {} is not available", action);
        }



    }


}
