package com.tr.cbgd.report;

public @interface FromEnum {
}
