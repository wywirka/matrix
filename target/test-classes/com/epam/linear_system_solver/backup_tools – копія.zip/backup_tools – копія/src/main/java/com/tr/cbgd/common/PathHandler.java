package com.tr.cbgd.common;

import org.apache.hadoop.fs.Path;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class PathHandler {

    public PathHandler() {

    }


    public String generateFileName(String oldName){
        return "_backup_" + new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
    }

    public List<String> fileIntersection(Set<String> set1, Set<String> set2){
        return set1.stream().filter(s -> set2.contains(s)).collect(Collectors.toList());
    }

    public List<String> fileSymDifference(Set<String> set1, Set<String> set2){
        return Stream.concat(
                set1.stream().filter(e -> !set2.contains(e)),
                set2.stream().filter(i -> !set1.contains(i))
                ).collect(Collectors.toList());
    }

}
