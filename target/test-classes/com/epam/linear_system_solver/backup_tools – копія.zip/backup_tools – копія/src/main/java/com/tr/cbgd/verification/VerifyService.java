package com.tr.cbgd.verification;

import com.tr.cbgd.common.HDFSManager;
import com.tr.cbgd.common.HbaseManager;
import com.tr.cbgd.config.HbaseProperties;
import com.tr.cbgd.config.HdfsProperties;
import com.tr.cbgd.report.Status;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.protobuf.generated.HBaseProtos;

import java.io.IOException;
import java.util.List;

@Slf4j
public class VerifyService {

    private static final int EXPECTED_SIZE = 2;
    private static final Path ORIGINAL_PATH = new Path("/project/trdev/tr-iryna");
    private HbaseManager dbManager;
    private HDFSManager fsManager;
    private HbaseProperties hbProps;
    private HdfsProperties hdfsProps;


    public VerifyService(HbaseManager dbManager, HDFSManager fsManager, HbaseProperties hbProps, HdfsProperties hdfsProps) {
        this.dbManager = dbManager;
        this.fsManager = fsManager;
        this.hbProps = hbProps;
        this.hdfsProps = hdfsProps;
    }

    public CheckingResult verify(Path snapPath){
        Status status;
        String message;
        try{
            Path tempPath;
            tempPath = fsManager.copyToNew(snapPath, hdfsProps.getTempPath());
            log.info("Cloned path to temp location {}", hdfsProps.getTempPath());
//            Old solution - list of non identical files - I thought it was a bit redundant
            String  differenceMessage = fsManager.checkFilesIdentity(ORIGINAL_PATH,tempPath);
            log.info("Copied files and Original files are not identical");
            status = StringUtils.isEmpty(differenceMessage) ? Status.VALID  : Status.INVALID;
            message = differenceMessage;
            fsManager.delete(tempPath);
        }catch (IOException e){
            status = Status.INVALID;
            message = e.getMessage();
        }
//        replace with builder ?
        return new CheckingResult(status, message);
    }

        public CheckingResult verify(List<HBaseProtos.SnapshotDescription> dbSnapshots){
        log.info("Snapshot number {}", dbSnapshots.size());
        if (dbSnapshots.size() != EXPECTED_SIZE){
            return new CheckingResult(Status.INVALID, "Number of current snapshots is less than expected");
        }

        try {
            for (HBaseProtos.SnapshotDescription snapshot : dbSnapshots) {
                if (!dbManager.isCorrectSnapshot(snapshot, TableName.valueOf(snapshot.getTable()))) {
                    return new CheckingResult(Status.INVALID, "Snapshot metadata " + snapshot.getName() + " are inconcictent");
                }
            }
        }
        catch(IOException e){
            return new CheckingResult(Status.INVALID, "Issue with HDFS");
        }

        return new CheckingResult(Status.VALID, "");
    }
//
    public CheckingResult verifyExtended(List<HBaseProtos.SnapshotDescription> dbSnapshots){

        try{
            for (HBaseProtos.SnapshotDescription snapshot : dbSnapshots) {
                TableName originalTable = TableName.valueOf(snapshot.getTable());
                TableName clonedTable = dbManager.clone(snapshot);
                log.info("Cloned table name", clonedTable.getNameAsString());
                long countResult = dbManager.checkRowCount(originalTable, clonedTable,snapshot.getCreationTime()+1L);
                dbManager.delete(clonedTable);
                if (countResult !=0 ) {
                    return new CheckingResult(Status.INVALID, "Rows in snapshot " + snapshot.getName() + " are inconsistent " + countResult);
                }
            }
        }
        catch (IOException e){
            return new CheckingResult(Status.INVALID, "Hbase related issue");
        }


        return new CheckingResult(Status.VALID, "");
    }




//    public List<VerificationReport> verify(List<HBaseProtos.SnapshotDescription> dbSnapshots){
//        List reports = new ArrayList();
//        log.info("Snapshot number {}", dbSnapshots.size());
//        if (dbSnapshots.size() == EXPECTED_SIZE){
//            for (HBaseProtos.SnapshotDescription snapshot: dbSnapshots) {
//                reports.add(verify(snapshot));
//            }
//        }
//        else{
//            for (HBaseProtos.SnapshotDescription snap: dbSnapshots){
//                reports.add(new VerificationReport(snap.getName(), "INVALID", "Number of current snapshots is less than expected"));
//            }
//        }
//        return reports;
//    }

//    public VerificationReport verify(HBaseProtos.SnapshotDescription dbSnap){
//        String status;
//        String message="";
//        TableName originalTable = TableName.valueOf(dbSnap.getTable());
//        log.info("Snapshot origin - {} table", originalTable.getNameAsString());
//        try{
//            boolean isSchemaValid = dbManager.isCorrectSnapshot(dbSnap, originalTable);
//            log.info("isSchemaValid {}", isSchemaValid);
//            if(isSchemaValid){
//                TableName clonedTable = dbManager.clone(dbSnap);
//                log.info("Cloned table name", clonedTable.getNameAsString());
//                long countResult = dbManager.checkRowCount(originalTable, clonedTable,dbSnap.getCreationTime()+1L);
//                dbManager.delete(clonedTable);
//                if(countResult == 0){
//                    status = "VALID";
//                }
//                else{
//                    status = "INVALID";
//                    message = countResult>0 ? originalTable.getNameAsString(): clonedTable.getNameAsString() +"has "+ Math.abs(countResult) + "more records";
//                }
//            }
//            else {
//                status = "INVALID";
//                message = "Snapshot is corrupted";
//            }
//
//        }
//        catch(IOException e){
//            status = "UNKNOWN";
//            message = e.getMessage();
//        }
//        return new VerificationReport(dbSnap.getName(), status, message);
//    }


}
