package com.tr.cbgd.verification;

import com.tr.cbgd.report.Status;

public class CheckingResult {
    private Status status;
    private String message;

    public CheckingResult(Status status, String message) {
        this.status = status;
        this.message = message;
    }

    public Status getStatus() {
        return status;
    }

    public String getMessage() {
        return message;
    }
}
