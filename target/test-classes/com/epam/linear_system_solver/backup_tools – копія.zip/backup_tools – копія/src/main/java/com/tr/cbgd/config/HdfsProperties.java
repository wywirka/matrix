package com.tr.cbgd.config;

import org.apache.hadoop.fs.Path;

public class HdfsProperties {

    private String originalPath;
    private String snapshotPath;
    private String tempPath;

    public Path getOriginalPath() {
        return new Path(originalPath);
    }

    public Path getSnapshotPath() {
        return new Path(snapshotPath);
    }

    public Path getTempPath() { return new Path(tempPath) ; }
}
