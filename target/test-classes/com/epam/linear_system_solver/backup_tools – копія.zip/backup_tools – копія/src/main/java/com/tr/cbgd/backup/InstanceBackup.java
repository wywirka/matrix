package com.tr.cbgd.backup;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hbase.protobuf.generated.HBaseProtos;

import java.util.List;

public class InstanceBackup {

    private String name;
    private String date;
    private String firmId;
    private List<HBaseProtos.SnapshotDescription> hbaseSnapshots;
    private Path hdfsSnapshot;


    public InstanceBackup(String name, String date, String firmId, List<HBaseProtos.SnapshotDescription> hbaseSnapshots, Path hdfsSnapshot) {
        this.name = name;
        this.date = date;
        this.firmId = firmId;
        this.hbaseSnapshots = hbaseSnapshots;
        this.hdfsSnapshot = hdfsSnapshot;
    }

    public String getName() {
        return name;
    }

    public String getDate() {  return date; }

    public List<HBaseProtos.SnapshotDescription> getHbaseSnapshots() {
        return hbaseSnapshots;
    }

    public Path getHdfsSnapshot() {
        return hdfsSnapshot;
    }

    public String getFirmId() {
        return firmId;
    }

    @Override
    public String toString() {
        return "InstanceBackup{" +
                "name='" + name + '\'' +
                ", date='" + date + '\'' +
                ", hbaseSnapshots=" + hbaseSnapshots.get(0).getName()  +
                ", hdfsSnapshot=" + hdfsSnapshot +
                '}';
    }
}

