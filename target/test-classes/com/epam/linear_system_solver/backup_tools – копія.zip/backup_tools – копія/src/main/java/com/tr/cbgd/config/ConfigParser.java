package com.tr.cbgd.config;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;


import java.io.File;
import java.io.IOException;

public class ConfigParser {

    public static CommonProperties parse(String configPath) throws IOException {
        ObjectMapper mapper = new ObjectMapper(new YAMLFactory());
        CommonProperties appProperties = mapper.readValue(new File(configPath), CommonProperties.class);
        return appProperties;
    }
}
