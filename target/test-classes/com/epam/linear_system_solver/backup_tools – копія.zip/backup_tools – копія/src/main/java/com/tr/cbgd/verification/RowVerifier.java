package com.tr.cbgd.verification;

import com.tr.cbgd.backup.InstanceBackup;
import com.tr.cbgd.report.VerificationReport;

public class RowVerifier extends Verifier {

    private VerifyService verifyService;

    public RowVerifier(VerifyService verifyService) {
        this.verifyService = verifyService;
    }


    @Override
    public CheckingResult verifyItem(InstanceBackup ins) {
        return verifyService.verifyExtended(ins.getHbaseSnapshots());
    }
    //    @Override
//    public Verifier setNext(Verifier verifier) {
//        return super.setNext(verifier);
//    }
//
//    @Override
//    public boolean hasNext() {
//        return super.hasNext();
//    }
}
