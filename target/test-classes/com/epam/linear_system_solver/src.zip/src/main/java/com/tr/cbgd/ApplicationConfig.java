package com.tr.cbgd;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hbase.HBaseConfiguration;

public class ApplicationConfig {

    public static Path HBASE_SITE = new Path("C:\\ProgramFiles\\hbase-1.6.0\\conf\\hbase-site.xml");
    public static Path CORE_SITE = new Path("C:\\ProgramFiles\\hadoop-2.9.2\\etc\\hadoop\\core-site.xml");
    public static Path HDFS_SITE = new Path("C:\\ProgramFiles\\hadoop-2.9.2\\etc\\hadoop\\hdfs-site.xml");

    public static Configuration getConfig(){
        Configuration config = HBaseConfiguration.create();
        config.addResource(HBASE_SITE);
        config.addResource(CORE_SITE);
        config.addResource(HDFS_SITE);
        return config;
    }

}
