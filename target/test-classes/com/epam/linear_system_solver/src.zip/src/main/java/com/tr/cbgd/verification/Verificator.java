package com.tr.cbgd.verification;

import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.protobuf.generated.HBaseProtos;

public class Verificator {
    private HBaseProtos.SnapshotDescription snapInfo;
    private TableName table;

    public Verificator(HBaseProtos.SnapshotDescription snapInfo, TableName table) {
        this.snapInfo = snapInfo;
        this.table = table;
    }

}
