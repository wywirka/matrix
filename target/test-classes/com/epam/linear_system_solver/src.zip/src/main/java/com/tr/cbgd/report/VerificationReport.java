package com.tr.cbgd.report;

import com.tr.cbgd.verification.Cell;
import com.tr.cbgd.verification.FromEnum;

public class VerificationReport {
//    @RowKey
    private String id;
    @Cell(columnFamily = "info", column="time")
    private String time;
//    @FromEnum
    @Cell(columnFamily = "info", column="status")
    private String status;
    @Cell(columnFamily = "info", column="message")
    private String message;

    public VerificationReport() {
    }

    public VerificationReport(String id, String time, String status, String message) {
        this.id = id;
        this.time = time;
        this.status = status;
        this.message = message;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    @Override
    public String toString() {
        return "VerificationReport{" +
                "id='" + id + '\'' +
                ", status='" + status + '\'' +
                ", message='" + message + '\'' +
                '}';
    }
}
