package com.tr.cbgd.verification;

public @interface FromEnum {

}
