package com.tr.cbgd.verification;

import com.tr.cbgd.PathHandler;
import com.tr.cbgd.report.VerificationReport;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class HDFSVerificationManager {

    private static Logger log = LoggerFactory.getLogger(HDFSVerificationManager.class);

    private FileSystem dfs;
    private Configuration conf;
    private PathHandler handler;
//    private Path snapshotPath;
//    private Path tmpPath;


    public HDFSVerificationManager(FileSystem dfs, Configuration conf, PathHandler handler) {
        this.dfs = dfs;
        this.conf = conf;
        this.handler = handler;
    }

    public VerificationReport verify(FileStatus fs, String instance){
        String status;
        String message=null;
        Path originalPath = handler.getOriginalPath(instance);
        Path tempPathIns = handler.createTempPath(fs, instance);
        log.info("Original path {}", originalPath);
        log.info("Temp path {}", tempPathIns);
        if(tempPathIns == null){
            status = "INVALID";
            message = "Snapshot can't be copied";
        }
        else{
            try{
                RemoteIterator tmpIter = dfs.listFiles(tempPathIns, true);
                List<LocatedFileStatus> innerFiles = toList(tmpIter);
                List<LocatedFileStatus> inconsistentLFS =  innerFiles.stream().filter(lfs -> ! isIdentical(lfs, tempPathIns, instance)).collect(Collectors.toList());
                if (!inconsistentLFS.isEmpty()){
                    status = "INVALID";
                    message = "Checksums doesn't match for next files: "  + inconsistentLFS.stream().map(i -> i.getPath().getName()).collect(Collectors.joining(", "));
                }
                else {
                    status = "VALID";
                }

            }
            catch (IOException e){
                log.error("exception when files are listed");
                status = "INVALID";
                message = "instance folder files can't be listed";
            }
        }

        try{
            dfs.delete(tempPathIns,true);
        }catch (IOException e){
            log.error("Temp folder can't be deleted");
        }

        return new VerificationReport(fs.getPath().getName(), String.valueOf(fs.getModificationTime()), status, message);
    }

    public List<VerificationReport> verify(List<FileStatus> snapPaths, String instance){
        log.info("List size {}",snapPaths.size());
        return snapPaths.stream().map(p -> verify(p, instance)).collect(Collectors.toList());

    }

    private List toList(RemoteIterator iter) throws IOException{
        List<LocatedFileStatus> fileList = new ArrayList<>();

            while(iter.hasNext()) {
                fileList.add((LocatedFileStatus) iter.next());
            }


        return fileList;
    }

    private boolean isIdentical(LocatedFileStatus lfs, Path tmp, String ins){
//        String relative = lfs.getPath().toUri().relativize(tmp.toUri()).getPath();
//        log.info("Relative Path {}", relative);
        String p1 = lfs.getPath().toString();
        log.info("Path1 {}", p1);
        String p2 = "/project/trdev" + p1.split(ins)[1];
        Path pp2 = new Path("/project/trdev" + "/" + ins + "/" + p1.split(ins)[1]);
        log.info("Path2 {}", pp2.toString());
        boolean result =true;
        try{
            result = dfs.getFileChecksum(lfs.getPath()).equals(dfs.getFileChecksum(pp2));
        }
        catch (IOException ex){
            return false;
        }
        return result;
    }


}
