package com.tr.cbgd.filtering;

import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.hbase.client.Connection;
import org.apache.hadoop.hbase.protobuf.generated.HBaseProtos;

import java.io.IOException;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class HbaseSnapshotFilter {

    private Connection conn;

    public HbaseSnapshotFilter(Connection conn) {
        this.conn = conn;
    }

    public List<HBaseProtos.SnapshotDescription> filter(Predicate<HBaseProtos.SnapshotDescription> filterType) throws IOException{
        return conn.getAdmin().listSnapshots().stream().filter(z -> filterType.test(z)).collect(Collectors.toList());

    }




//    public List<HBaseProtos.SnapshotDescription> filter(String instance, String date) throws IOException {
//        return conn.getAdmin().listSnapshots().stream().filter(l -> l.getName().contains(instance) && l.getName().contains(date)).collect(Collectors.toList());
//
//    }
}
