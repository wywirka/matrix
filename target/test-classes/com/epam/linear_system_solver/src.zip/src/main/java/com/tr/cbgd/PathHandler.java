package com.tr.cbgd;

import com.tr.cbgd.filtering.HDFSSnapshotFilter;
import com.tr.cbgd.verification.HDFSVerificationManager;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.FileUtil;
import org.apache.hadoop.fs.Path;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

public class PathHandler {

    private static Logger log = LoggerFactory.getLogger(PathHandler.class);

    private Configuration conf;
    private FileSystem dfs;
//    private HDFSProperties props;


    public PathHandler(Configuration conf, FileSystem dfs) {
        this.conf = conf;
        this.dfs = dfs;

    }

    public  Path getOriginalPath(String instance){
       return new Path("/project/trdev", instance);
   }


    public Path getBasePath(){
        return new Path("/project/trdev");
    }

    public Path createTempPath(FileStatus path, String instance){
       boolean result;
       log.info("P {}",path);
       log.info(path.getPath().toString()+"/trdev/"+instance);
//       log.info("Path 1:", new Path(path.getPath().getName() +  "/trdev/"+ instance));
       log.info("/tmp/ver-target");
       try{
           result = FileUtil.copy(dfs, new Path(path.getPath().toString()+"/trdev/"+instance), dfs, new Path("/tmp/ver-target"), false, conf);

       }
       catch (IOException e){
           log.error("Copy to temp location was failed");
           return null;
       }
       return result ? new Path("/tmp/ver-target", instance): null;
   }

}
