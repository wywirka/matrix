package com.tr.cbgd;

public class HbaseProperties {
    private String nameSpace;
    private int tbNumber;

    public HbaseProperties(String nameSpace, int tbNumber) {
        this.nameSpace = nameSpace;
        this.tbNumber = tbNumber;
    }
}
