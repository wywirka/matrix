package com.tr.cbgd.verification;

public enum Status {
    VALID,
    INVALID
}
