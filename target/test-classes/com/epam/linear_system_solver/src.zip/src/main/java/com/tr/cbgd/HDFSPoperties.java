package com.tr.cbgd;

public class HDFSPoperties {

    private String snapshottableDir;
    private String tempDir;

    public HDFSPoperties(String snapshottableDir, String tempDir) {
        this.snapshottableDir = snapshottableDir;
        this.tempDir = tempDir;
    }
}
