package com.tr.cbgd;

import com.tr.cbgd.filtering.HDFSSnapshotFilter;
import com.tr.cbgd.filtering.HbaseSnapshotFilter;
import com.tr.cbgd.report.ConsoleResultHandler;
import com.tr.cbgd.report.HbaseResultHandler;
import com.tr.cbgd.report.ReportHandler;
import com.tr.cbgd.report.VerificationReport;
import com.tr.cbgd.verification.HDFSVerificationManager;
import com.tr.cbgd.verification.HbaseVerificationManager;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hbase.client.Connection;
import org.apache.hadoop.hbase.client.ConnectionFactory;
import org.apache.hadoop.hbase.protobuf.generated.HBaseProtos;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;

import static java.lang.String.valueOf;

public class HbaseHDFSBackup {

    private static final Logger log = LoggerFactory.getLogger(HbaseHDFSBackup.class);
//    private static Logger log = Logger.getLogger(HbaseHDFSBackup.class);
    private static final int EXPECTED = 2;

    public static void main(String[] args) throws IOException {
        String action = args[0];
        String instance =  args[1];
//        String index = args[2];
        if(instance == ""){
            throw new IllegalArgumentException("instance is required argument");
        }

        Configuration configs =  ApplicationConfig.getConfig();
        FileSystem dfs = FileSystem.get(configs);
        Connection conn = ConnectionFactory.createConnection(configs);
        log.info(conn.toString());

        if(action.equals("list")){
            log.info("{} action was picked", action);
        }
        else if(action.equals("verify")){
            log.info("{} action was picked", action);
            HbaseSnapshotFilter verificationFilter = new HbaseSnapshotFilter(conn);
            HbaseVerificationManager verificator = new HbaseVerificationManager(conn.getAdmin(), conn );
            Predicate<HBaseProtos.SnapshotDescription> hbFilter = (s) -> s.getName().contains(instance)&& s.getName().contains("2020-08-26");
            List<HBaseProtos.SnapshotDescription> hbFilterResult = verificationFilter.filter(hbFilter);
            List<VerificationReport> reports = verificator.verify(hbFilterResult, EXPECTED);


            HDFSSnapshotFilter hdfsVerificationFilter = new HDFSSnapshotFilter(dfs);
            PathHandler ph = new PathHandler(configs, dfs);
            HDFSVerificationManager hdfsVerificator = new HDFSVerificationManager(dfs,configs, ph);

            Predicate<FileStatus> hdfsFilter = (l) -> l.getPath().getName().contains("2020-08-26");
            List<FileStatus> hdfsFiltResult = hdfsVerificationFilter.filter(hdfsFilter, new Path("/project/.snapshot"));
            List<VerificationReport> rep = hdfsVerificator.verify(hdfsFiltResult, instance);
//            List<VerificationReport> rs = Arrays.asList(new VerificationReport("snap_2020-08-22_tr.tr-iryna_adjustments", "new Long(1)", "VALID", null), new VerificationReport("snap_2020-08-22_tr.tr-iryna_datalocator", "new Long(2)", "VALID", null));
//            ReportHandler rh = new HbaseResultHandler(conn, "tr:verification-result");
            ReportHandler ch = new ConsoleResultHandler();
//            rh.setNext(ch);
            ch.handle(rep);
            ch.handle(reports);
        }
        else if(action.equals("restore")){
            log.info("{} action was picked", action);
        }
        else{
            log.info("Command {} is not found ", action);
        }

//
//
//       HbaseSnapshotFilter verificationFilter = new HbaseSnapshotFilter(conn);
//        HbaseVerificationManager verificator = new HbaseVerificationManager(conn.getAdmin(), conn );
//        HbaseResultHandler hbaseConsumer = new HbaseResultHandler(conn);
//
//
//        Predicate<HBaseProtos.SnapshotDescription> hbFilter = (s) -> s.getName().contains(instance)&& s.getName().contains("2020-08-26");
//        List<HBaseProtos.SnapshotDescription> hbFilterResult = verificationFilter.filter(hbFilter);
//        List<VerificationReport> reports = verificator.verify(hbFilterResult, EXPECTED);
//        hbaseConsumer.write(reports);
//
//
//
    }



}
