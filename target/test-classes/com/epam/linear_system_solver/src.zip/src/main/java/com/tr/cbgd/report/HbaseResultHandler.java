package com.tr.cbgd.report;



import com.tr.cbgd.verification.Cell;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.Connection;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.Table;
import org.apache.hadoop.hbase.util.Bytes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.lang.reflect.Field;
import java.util.List;
import java.util.stream.Collectors;

public class HbaseResultHandler extends ReportHandler{

    private static final Logger log = LoggerFactory.getLogger(HbaseResultHandler.class);

    private Connection connection;
    private String tbName;


    public HbaseResultHandler(Connection connection, String tbName) {
        this.connection = connection;
        this.tbName = tbName;
    }

    @Override
    public void handle(List<VerificationReport> reports) {
        List<Put> puts = reports.stream().map(i->toPut(i)).collect(Collectors.toList());
        write(puts);
        if(hasNext()){
            super.next.handle(reports);
        }
    }

    @Override
    public ReportHandler setNext(ReportHandler handler) {
        return super.setNext(handler);
    }

    @Override
    public boolean hasNext() {
        return super.hasNext();
    }

    //    @Override
//    public void handle(VerificationReport report) {
//        toPut(report);
//    }

    public void write(List<Put> puts) {
        try{
            Table table = connection.getTable(TableName.valueOf(tbName));
            table.put(puts);
        }
        catch (IOException e){
            log.error("Table {} is not found", tbName);
        }
    }

    public Put toPut(VerificationReport report){
        Put put = new Put(Bytes.toBytes(report.getId()));
        Field fields []  = report.getClass().getDeclaredFields();
        log.info("Report is converting to Hbase put");
        for(Field f : fields){
            if(f.isAnnotationPresent(Cell.class)){
                Cell annotation = f.getAnnotation(Cell.class);
                try{
                    f.setAccessible(true);
                    if(f.get(report) != null){
                        log.info("Field name {}", f.getName());
                        put.addColumn(Bytes.toBytes(annotation.columnFamily()), Bytes.toBytes(annotation.column()), Bytes.toBytes((String) f.get(report)));
                    }
                }catch (IllegalArgumentException | IllegalAccessException e){
                    log.error("Annotation issue", e);
                }
            }
        }
        return put;
    }

}
