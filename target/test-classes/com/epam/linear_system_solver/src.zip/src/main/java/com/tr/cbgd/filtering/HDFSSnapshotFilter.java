package com.tr.cbgd.filtering;

import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hbase.client.Connection;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class HDFSSnapshotFilter {

    private FileSystem dfs;

    public HDFSSnapshotFilter(FileSystem dfs) {
        this.dfs = dfs;
    }

    public List<FileStatus> filter(Predicate<FileStatus> filterType, Path path) throws IOException {
        return Arrays.asList(dfs.listStatus(path)).stream().filter(z -> filterType.test(z)).collect(Collectors.toList());

    }
}
