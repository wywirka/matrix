package com.tr.cbgd.verification;

import com.tr.cbgd.report.VerificationReport;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.*;
import org.apache.hadoop.hbase.protobuf.generated.HBaseProtos;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

public class HbaseVerificationManager {
    private static Logger log = LoggerFactory.getLogger(HbaseVerificationManager.class);


    private Admin hbAdmin;
    private Connection conn;

    public HbaseVerificationManager(Admin hbAdmin, Connection conn) {
        this.hbAdmin = hbAdmin;
        this.conn = conn;
    }

    public List<VerificationReport> verify(List<HBaseProtos.SnapshotDescription> snapshots, int expected){

        if(snapshots.size() == expected){
            return snapshots.stream().map(s -> verify(s)).collect(Collectors.toList());
        }
        else{
            return snapshots.stream().map(s->toReport(s)).collect(Collectors.toList());

        }
    }

    public VerificationReport toReport(HBaseProtos.SnapshotDescription snap){
        VerificationReport snapshotReport = new VerificationReport();
        snapshotReport.setId(snap.getName());
        snapshotReport.setTime(String.valueOf(snap.getCreationTime()));
        snapshotReport.setStatus("INVALID");
        snapshotReport.setMessage("Some tables are missing");
        return snapshotReport;
    }

    public VerificationReport verify(HBaseProtos.SnapshotDescription snapshot){
        System.out.println("Snap name:"+snapshot.getName());
        TableName originalTable = TableName.valueOf(snapshot.getTable());
        System.out.println("Original table name:"+ originalTable.getNameAsString());
        TableName clonedTable = runPreVerif(snapshot);
        VerificationReport report = new VerificationReport();
        report.setId(snapshot.getName());
        report.setTime(String.valueOf(snapshot.getCreationTime()));
        if(clonedTable != null){
            log.info("Original table name:"+ clonedTable.getNameAsString());
            try{
                long originalCount =  runRowCount(originalTable, snapshot.getCreationTime()+1L);
                System.out.println("Original table row count:"+ originalCount);
                long clonedRowCount = runRowCount(clonedTable);
                System.out.println("Cloned table row count:"+ clonedRowCount);
                if(originalCount == clonedRowCount){
                    System.out.println("Status VALID");
                    report.setStatus("VALID");
                }
                else{
                    log.info("INVALID");
                    report.setStatus("INVALID");
                    report.setMessage("Row number is inconsistent");
                }
                runPostVerif(clonedTable);
            }
            catch (IOException e){
                report.setStatus("UNKNOWN");
                report.setMessage("Environment issue occured during the verification ");
            }
        }
        else {
            System.out.println("Clone table failed");
        }
        return report;
    }

    private long runRowCount(TableName tableName) throws IOException{
        Scan scan = new Scan();
//        scan.setTimeRange(0, 1593712549572L);
        Table table = conn.getTable(tableName);
        ResultScanner scanner = table.getScanner(scan);
        long i =0L;
        // Reading values from scan result
        for (Result result = scanner.next(); result != null; result = scanner.next()){
            i++;
        }
        scanner.close();
        return i;

    }

    private long runRowCount(TableName tableName, long timeLimit) throws IOException{
        Scan scan = new Scan();
        scan.setTimeRange(0, timeLimit);
        Table table = conn.getTable(tableName);
        ResultScanner scanner = table.getScanner(scan);
        long i =0L;
        // Reading values from scan result
        for (Result result = scanner.next(); result != null; result = scanner.next()){
            i++;
        }
        scanner.close();
        return i;
    }


    private TableName runPreVerif(HBaseProtos.SnapshotDescription s ) {

      TableName t;
        try {
            System.out.println("CLONED");
            t = TableName.valueOf(s.getTable()+"_Temp");
            hbAdmin.cloneSnapshot(s.getName(), t);
        }
        catch(IOException e){
            return null;
        }

        return t;
    }

    private boolean runPostVerif(TableName tb){
        try {
            hbAdmin.disableTable(tb);
            hbAdmin.deleteTable(tb);
        }
        catch(IOException e){
            return false;
        }
        return true;
    }

}
