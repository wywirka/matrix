import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class ConsoleResultHandler extends ReportHandler{

    private static final Logger log = LoggerFactory.getLogger(ConsoleResultHandler.class);

    @Override
    public void handle(List<VerificationReport> reports) {
        log.info("Console handler is running");
        reports.stream().map(i -> i.toString()).forEach(System.out::println);

        if(hasNext()){
            next.handle(reports);
        }
    }

    @Override
    public ReportHandler setNext(ReportHandler handler) {
        return super.setNext(handler);
    }

    @Override
    public boolean hasNext() {
        return super.hasNext();
    }

    //    @Override
//    public void handle(VerificationReport report) {
//        System.out.println(report.toString());
//        if(hasNext()){
//            next.handle(report);
//        }
//    }


}
