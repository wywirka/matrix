public class VerificationReport {

    private String name;
    @Cell(columnFamily = "info", column="status")
    private String status;
    @Cell(columnFamily = "info", column="message")
    private String message;

    public VerificationReport(String name, String status) {
        this.name = name;
        this.status = status;
    }

    public VerificationReport(String name, String status, String message) {
        this.name = name;
        this.status = status;
        this.message = message;
    }

    public String getName() {
        return name;
    }

    public String getStatus() {
        return status;
    }

    public String getMessage() {
        return message;
    }

    @Override
    public String toString() {
        return "VerificationReport{" +
                "name='" + name + '\'' +
                ", status='" + status + '\'' +
                ", message='" + message + '\'' +
                '}';
    }
}
