import org.apache.hadoop.fs.Path;

public class PathHandler {

    private String basePath;
    private String tmpPath;

    public PathHandler(String basePath, String tmpPath) {
        this.basePath = basePath;
        this.tmpPath = tmpPath;
    }

    //    /project/trdev/instances
    public Path getBasePath() {
        return new Path(basePath);
    }

//     /tmp/ver-destination
    public Path getTmpPath() {
        return new Path(tmpPath);
    }
}
