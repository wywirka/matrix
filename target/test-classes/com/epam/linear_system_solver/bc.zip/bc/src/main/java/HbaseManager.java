
import lombok.extern.slf4j.Slf4j;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hbase.*;
import org.apache.hadoop.hbase.Cell;
import org.apache.hadoop.hbase.client.*;
import org.apache.hadoop.hbase.protobuf.generated.HBaseProtos;
import org.apache.hadoop.hbase.snapshot.SnapshotDescriptionUtils;
import org.apache.hadoop.hbase.snapshot.SnapshotInfo;
import org.apache.hadoop.hbase.snapshot.SnapshotManifest;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.hadoop.hbase.util.FSUtils;

import java.io.IOException;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import static org.apache.hadoop.hbase.snapshot.SnapshotInfo.getSnapshotStats;

@Slf4j
public class HbaseManager {
    private final static String TB_POSTFIX = "_temp";

    private Configuration config;
    private Connection conn;
    private Admin admin;
    private FileSystem dfs;

    public HbaseManager(Configuration config, Connection conn, Admin admin, FileSystem dfs) {
        this.config = config;
        this.conn = conn;
        this.admin = admin;
        this.dfs = dfs;
    }

    public boolean isCorrectSnapshot(HBaseProtos.SnapshotDescription snapDescription, TableName tableName) throws IOException{
        SnapshotInfo.SnapshotStats snapStats = SnapshotInfo.getSnapshotStats(config, snapDescription);
//        Path rootDir = FSUtils.getRootDir(config);
//        Path snapshotDir = SnapshotDescriptionUtils.getSnapshotsDir(rootDir);
//        log.info(snapshotDir.toString());
//        log.info(dfs);
//        SnapshotManifest manifest  = SnapshotManifest.open(config, dfs, snapshotDir, snapDescription);
//        HTableDescriptor snapSchema = manifest.getTableDescriptor();
//        HTableDescriptor tableSchema = new HTableDescriptor(tableName);
//        log.info("Snapshot schema", snapSchema.toString());
//        log.info("Table schema", tableSchema.toString());
        log.info("If snapshot is corrupted {}", snapStats.isSnapshotCorrupted());
        return ! snapStats.isSnapshotCorrupted() ;
//                && snapSchema.equals(tableSchema);
    }

    public void restore(List<HBaseProtos.SnapshotDescription> snapshots) throws IOException {
        for(HBaseProtos.SnapshotDescription snap: snapshots){
            log.info("Snapshot {} is restoring", snap.getName());
            admin.restoreSnapshot(snap.getName());
        }
    }


    public List<HBaseProtos.SnapshotDescription> listSnapshots() throws IOException{
        return conn.getAdmin().listSnapshots();
    }

    public TableName clone(HBaseProtos.SnapshotDescription snapshot) throws IOException{
        String tbName = snapshot.getTable() + TB_POSTFIX;
        return clone(snapshot, tbName);

    }

    public TableName clone(HBaseProtos.SnapshotDescription snapshot, String newName) throws IOException {
        TableName tbName = TableName.valueOf(newName);
        try {
            conn.getAdmin().cloneSnapshot(snapshot.getName(), tbName);
        }
        catch (IOException e){
            log.error("Snaphot {} can't be cloned to {}",snapshot.getName(), newName);
            throw new IOException("Clone operation failed");
        }
        return tbName;
    }

    public long checkRowCount(TableName tab1, TableName tab2, long timeLimit) throws IOException{
        return countRows(tab1,timeLimit) - countRows(tab2, timeLimit);
    }


    private long countRows(TableName tableName, long timeLimit) throws IOException{
        Table table = conn.getTable(tableName);
        Scan scanner = new Scan();
        scanner.setTimeRange(0, timeLimit);
        ResultScanner scanResults = table.getScanner(scanner);
        long i =0L;
        for(Result result : scanResults){
            i++;
        }
        log.info("{} rows in {}",i, tableName.getNameAsString());
        scanResults.close();
        return i;
    }


    public void delete(TableName tableName) throws IOException{
        try{
            admin.disableTable(tableName);
            admin.deleteTable(tableName);
        }catch (IOException e){
            log.error("Table can't be deleted");
            throw new IOException("Table can't be deleted");
        }

    }

    public void write(List<Put> puts, String tbName) {
        try{
            Table table = conn.getTable(TableName.valueOf(tbName));
            table.put(puts);
        }
        catch (IOException e){
            log.error("Table {} is not found", tbName);
        }
    }


    public void updateTable(String rowKey) throws IOException{
        HBaseProtos.SnapshotDescription snapshot = listSnapshots().stream().filter(i->i.getName().contains("instances")).collect(Collectors.toList()).get(0);
        TableName clonedName = clone(snapshot);
        Table clonedTable = conn.getTable(clonedName);
        Get get = new Get(Bytes.toBytes(rowKey));
        Put put = new Put(Bytes.toBytes(rowKey));
        Result result = clonedTable.get(get);
//        CellScanner cs = result.cellScanner();

        for(Cell cell : result.rawCells()) {
            log.info("Cell in processing {}",cell);
            put.add(CellUtil.cloneFamily(cell),
                    CellUtil.cloneQualifier(cell), CellUtil.cloneValue(cell));
        }
        log.info("Put after insert {}",put);
        Table original = conn.getTable(TableName.valueOf(snapshot.getTable()));
        System.out.println(original);
        original.put(put);
        original.close();
        delete(clonedName);
    }

}
