import lombok.extern.slf4j.Slf4j;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.FileUtil;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.Connection;
import org.apache.hadoop.hbase.protobuf.generated.HBaseProtos;

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
public class RestoreService {

    private HbaseManager dbManager;
    private HDFSManager fsManager;

    public RestoreService(HbaseManager dbManager, HDFSManager fsManager) {
        this.dbManager = dbManager;
        this.fsManager = fsManager;
    }


//    public List<HBaseProtos.SnapshotDescription> listSnapshots() throws IOException {
//        return dbManager.listSnapshots();
//    }

    public void restore(Instance ins) throws IOException{
        try {
            dbManager.restore(ins.getDbSnapshots());
//            fsManager.restore(ins.getSnapLocation());
            dbManager.updateTable(ins.getName());
        }catch (IOException e){
            log.error("Restore attempt failed {}", e.getMessage());
            throw new IOException("Restore attempt failed");
        }

    }

    //    public void restore(List<HBaseProtos.SnapshotDescription> snapshots) throws IOException {
//        for(HBaseProtos.SnapshotDescription snap: snapshots){
//            restore(snap);
//        }
//    }
//
//    public void restore(HBaseProtos.SnapshotDescription snapshot) throws IOException{
//        connection.getAdmin().restoreSnapshot(snapshot.getName());
//    }
//
//    public void restore(Path snapshotPath) throws IOException{
//        FileUtil.copy(dfs, snapshotPath, dfs, new Path(""), false, conf);
//    }
}
