import lombok.extern.slf4j.Slf4j;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.protobuf.generated.HBaseProtos;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Slf4j
public class VerifyService {

    private static final int EXPECTED_SIZE = 2;
    private HbaseManager dbManager;
    private HDFSManager fsManager;

    public VerifyService(HbaseManager dbManager, HDFSManager fsManager) {
        this.dbManager = dbManager;
        this.fsManager = fsManager;
    }

    public VerificationReport verify(Path snapPath){
        String status;
        String message;
        Path tempPath;
        try{
            tempPath = fsManager.copyToNew(snapPath, fsManager.getTempLocation());
            log.info("Cloned path to temp location {}", fsManager.getTempLocation());
            List<String> difference = fsManager.checkIdentity(new Path("/project/trdev/tr-iryna"),tempPath);
            log.info("Non identical file number", difference.size());
            status = difference.isEmpty() ? "VALID"  : "INVALID";
            message = difference.isEmpty() ? "" : difference.toString();
            fsManager.delete(tempPath);
        }catch (IOException e){
            status = "UNKNOWN";
            message = e.getMessage();
        }

        return new VerificationReport(snapPath.toString(), status, message);
    }

    public List<VerificationReport> verify(List<HBaseProtos.SnapshotDescription> dbSnapshots){
        List reports = new ArrayList();
        log.info("Snapshot number {}", dbSnapshots.size());
        if (dbSnapshots.size() == EXPECTED_SIZE){
            for (HBaseProtos.SnapshotDescription snapshot: dbSnapshots) {
                reports.add(verify(snapshot));
            }
        }
        else{
            for (HBaseProtos.SnapshotDescription snap: dbSnapshots){
                reports.add(new VerificationReport(snap.getName(), "INVALID", "Number of current snapshots is less than expected"));
            }
        }
        return reports;
    }

    public VerificationReport verify(HBaseProtos.SnapshotDescription dbSnap){
        String status;
        String message="";
        TableName originalTable = TableName.valueOf(dbSnap.getTable());
        log.info("Snapshot origin - {} table", originalTable.getNameAsString());
        try{
            boolean isSchemaValid = dbManager.isCorrectSnapshot(dbSnap, originalTable);
            log.info("isSchemaValid {}", isSchemaValid);
            if(isSchemaValid){
                TableName clonedTable = dbManager.clone(dbSnap);
                log.info("Cloned table name", clonedTable.getNameAsString());
                long countResult = dbManager.checkRowCount(originalTable, clonedTable,dbSnap.getCreationTime()+1L);
                dbManager.delete(clonedTable);
                if(countResult == 0){
                    status = "VALID";
                }
                else{
                    status = "INVALID";
                    message = countResult>0 ? originalTable.getNameAsString(): clonedTable.getNameAsString() +"has "+ Math.abs(countResult) + "more records";
                }
            }
            else {
                status = "INVALID";
                message = "Snapshot is corrupted";
            }

        }
        catch(IOException e){
            status = "UNKNOWN";
            message = e.getMessage();
        }
        return new VerificationReport(dbSnap.getName(), status, message);
    }


}
