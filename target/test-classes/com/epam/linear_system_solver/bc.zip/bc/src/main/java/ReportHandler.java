import java.util.List;

public abstract class ReportHandler {

    protected ReportHandler next;

    public abstract void handle(List<VerificationReport> reports);
//    public abstract void handle(VerificationReport report);


    public ReportHandler setNext(ReportHandler handler){
        this.next = handler;
        return next;

    }

    public boolean hasNext(){
        return next != null;
    }

}
