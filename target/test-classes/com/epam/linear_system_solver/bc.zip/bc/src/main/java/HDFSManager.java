import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.*;

import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
public class HDFSManager {

    private Configuration conf;
    private FileSystem dfs;
    private PathHandler handler;
    private Path originalPath;
    private Path tempPath;


    public HDFSManager(Configuration conf, FileSystem dfs, PathHandler handler) {
        this.conf = conf;
        this.dfs = dfs;
        this.handler = handler;
        this.originalPath = handler.getBasePath();
        this.tempPath = handler.getTmpPath();
    }


    public Path getTempLocation(){
        return tempPath;
    }

    public Path getBasePath(){
        return handler.getBasePath();
    }

    public Path copyToNew(Path src, Path dst) throws IOException{
        try{
            boolean copyResult= FileUtil.copy(dfs, src, dfs, dst, false, conf);
            if(copyResult){
                Path result = new Path(dst, src.getName());
                log.info("{} directory was created ",result);
                return result;
            }
            else {
                log.error("copy operation from {} to {} wasn't successful ", src, dst);
                throw new IOException("copy operation from " +src + " to " + dst + " wasn't successful ");
            }
        }
        catch (IOException e){
            log.error("{} can't be copied to new location {}", src, dst);
            throw new IOException(src + " can't be copied to new location " + dst);
        }
    }

    public boolean delete(Path path) throws IOException{
        try{
            log.info("Path {} is deleting", path);
            return  dfs.delete(path,true);
        }catch (IOException e){
            log.error("Folder {} can't be deleted", path);
            throw new IOException("Folder {} can't be deleted" + path.toString());
        }
    }

    public List<String> checkIdentity(Path path1, Path path2) throws IOException {
        List<String> nonIdenticalFiles = new ArrayList<>();
        try{
            Set<String> fileSet1 = filesToSet(path1);
            Set<String> fileSet2 = filesToSet(path2);
            List<String> common = fileSet1.stream().filter(s -> fileSet2.contains(s)).collect(Collectors.toList());
            if (fileSet1.size() == fileSet2.size() && fileSet1.size() == common.size()) {
                for (String item : common) {
                    if (!isIdentical(item, originalPath, tempPath)) {
                        nonIdenticalFiles.add(item + "has different check sum");
                    }
                }
            }else{
                nonIdenticalFiles.add(path2.getParent() + " doesn't contain " + findFileDiff(fileSet1, fileSet2));
                nonIdenticalFiles.add(path1.getParent() + " doesn't contain " + findFileDiff(fileSet2, fileSet1));
            }
        }catch (IOException e){
            e.printStackTrace();
            log.error("identity can't be checked");
            throw new IOException("identity can't be checked");
        }
        return nonIdenticalFiles;
    }

    private Set<String> filesToSet(Path fullPath) throws IOException{
        Set<String> relPathSet = new HashSet();
        Path parent = fullPath.getParent();
        log.info("Parent folder {}", parent);
        RemoteIterator<LocatedFileStatus> rmIterator = dfs.listFiles(fullPath, true);
        while(rmIterator.hasNext()){
            FileStatus item = rmIterator.next();
            log.info("FS Item {}", item.getPath());
            String relPath = toRelative(item.getPath(), parent);
            log.info(relPath);
            relPathSet.add(relPath);
        }
        return relPathSet;
    }

    private String toRelative(Path absPath, Path base){
        log.info("Abs path {}",absPath.toString());
        log.info("Base path {}",base.toString());
        Path newAbs = new Path (absPath.toString().replace(dfs.getUri().toString(),""));
        log.info("New Abs path {}", newAbs);
        log.info("Relative {}", base.toUri().relativize(absPath.toUri()).getPath());
        return base.toUri().relativize(newAbs.toUri()).getPath();
    }


    private boolean isIdentical(String relPath, Path base1, Path base2) throws IOException{
            Path file1 = new Path(base1, relPath);
            Path file2 = new Path(base2, relPath);
            log.info("CHSUM result {}", dfs.getFileChecksum(file1).equals(dfs.getFileChecksum(file2)));
        return dfs.getFileChecksum(file1).equals(dfs.getFileChecksum(file2));
    }

    private String findFileDiff(Set fSet1, Set fSet2){
        return (String) fSet1.stream().filter(e -> !fSet2.contains(e)).collect(Collectors.joining(","));
    }

//    public boolean delete(Path path){
//        try{
//            if(dfs.exists(path)){
//                return dfs.delete(path, true);
//            }
//            log.warn("Location {} doesn't exists", path);
//        }catch(IOException e){
//
//        }
//        return
//
//    }

//    public boolean verify(Path snapPath){
//        String status;
//        String message=null;
//        Path originalPath = handler.getOriginalPath(instance);
//        Path tempPathIns = handler.createTempPath(fs, instance);
//        log.info("Original path {}", originalPath);
//        log.info("Temp path {}", tempPathIns);
//        if(tempPathIns == null){
//            status = "INVALID";
//            message = "Snapshot can't be copied";
//        }
//        else{
//            try{
//                RemoteIterator tmpIter = dfs.listFiles(tempPathIns, true);
//                List<LocatedFileStatus> innerFiles = toList(tmpIter);
//                List<LocatedFileStatus> inconsistentLFS =  innerFiles.stream().filter(lfs -> ! isIdentical(lfs, tempPathIns, instance)).collect(Collectors.toList());
//                if (!inconsistentLFS.isEmpty()){
//                    status = "INVALID";
//                    message = "Checksums doesn't match for next files: "  + inconsistentLFS.stream().map(i -> i.getPath().getName()).collect(Collectors.joining(", "));
//                }
//                else {
//                    status = "VALID";
//                }
//
//            }
//            catch (IOException e){
//                log.error("exception when files are listed");
//                status = "INVALID";
//                message = "instance folder files can't be listed";
//            }
//        }
//
//        try{
//            dfs.delete(tempPathIns,true);
//        }catch (IOException e){
//            log.error("Temp folder can't be deleted");
//        }
//
//    }

//    public VerificationReport verify(Path snapPath){
//
//        try{
//            FileUtil.copy(dfs, snapPath, dfs, tempPath, false, conf);
//
//            }
//        }
//        catch (IOException e){
//            status = "UNKNOWN";
//            message = e.getMessage();
//        }
//        finally {
//            dfs.delete(new Path(tempPath, instance), true);
//        }
//        return new VerificationReport(instance, status, message);
//    }
//
//
//    public checkIdentity(Path path1, Path path2){
//        Set<String> origFiles = filesToSet(originalPath, instance);
//        Set<String> tempFiles = filesToSet(tempPath, instance);
//        List<String> common = origFiles.stream().filter(s -> tempFiles.contains(s)).collect(Collectors.toList());
//        if (origFiles.size() == tempFiles.size() && origFiles.size() == common.size() ){
//            List<String> nonIdenticalFiles = new ArrayList<>();
//            for(String item: common){
//                if(! isIdentical(item,originalPath, tempPath)){
//                    nonIdenticalFiles.add(item);
//                }
//            }
//            status = nonIdenticalFiles.isEmpty() ? "VALID": "INVALID";
//            message = nonIdenticalFiles.isEmpty() ? "": "INVALID";
//        }
//        else{
//            status = "INVALID";
//            String origMessage = origFiles.stream().filter(e -> !tempFiles.contains(e)).collect(Collectors.joining(","));
//            String tempMesage = tempFiles.stream().filter(e -> !origFiles.contains(e)).collect(Collectors.joining(","));
//            message = "Files available only in original :" + origMessage + "\nFiles from temp location: " + tempMesage;
//
//    }
//
//    public void restore(Path snapPath) throws IOException{
//        String instance ="";
//        if(dfs.exists(new Path(originalPath, instance)){
//            Path tempPath = handler.generateTemp(instance);
//            dfs.rename(originalPath,tempPath );
//            FileUtil.copy(dfs, snapPath, dfs, origin, false, conf);
//            dfs.delete(tempPath, true);
//        }
//        else{
//            FileUtil.copy(dfs, snapPath, dfs, origin, false, conf);
//        }
//
//    }
//
//

//

//

//

//
//    public List<FileStatus> listFiles(Path path) throws IOException {
//        return Arrays.asList( dfs.listStatus(path));
//    }
}
