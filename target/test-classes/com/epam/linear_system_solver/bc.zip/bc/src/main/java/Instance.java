import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hbase.protobuf.generated.HBaseProtos;

import java.util.List;

public class Instance {

    private String name;
    private List<HBaseProtos.SnapshotDescription> dbSnapshots;
    private Path snapLocation;

    public Instance(String name, List<HBaseProtos.SnapshotDescription> dbSnapshots, Path snapLocation) {
        this.name = name;
        this.dbSnapshots = dbSnapshots;
        this.snapLocation = snapLocation;
    }

    public String getName() {
        return name;
    }

    public List<HBaseProtos.SnapshotDescription> getDbSnapshots() {
        return dbSnapshots;
    }

    public Path getSnapLocation() {
        return snapLocation;
    }
}
