package com.tr.cbgd;//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;

import com.tr.cbgd.report.ConsoleResultHandler;
import com.tr.cbgd.report.HbaseResultHandler;
import com.tr.cbgd.report.ReportHandler;
import com.tr.cbgd.report.VerificationReport;
import com.tr.cbgd.restoration.RestoreService;
import com.tr.cbgd.verification.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hbase.client.Admin;
import org.apache.hadoop.hbase.client.Connection;
import org.apache.hadoop.hbase.client.ConnectionFactory;
import org.apache.hadoop.hbase.protobuf.generated.HBaseProtos;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;


@Slf4j
public class CLIRunner {


    private static final String TABLE_NAME = "tr:verification-result";
    private static final String BASE_DIR = "/project/trdev";
    private static final String TEMP_DIR = "/tmp/ver-destination";
    private static final String LATEST_DATE = "2020-09-02";
    private static final String SNAPSHOT_PATH = "/project/.snapshot/daily-snap_2020-09-02/trdev";

    public static void main(String[] args) throws IOException {

        run(args);

    }

    public static void run(String[] args) throws IOException{
        Configuration configs =  AppConfig.getConfig();
        Connection connection = ConnectionFactory.createConnection(configs);
        Admin admin = connection.getAdmin();
        FileSystem dfs = FileSystem.get(configs);
        PathHandler pathHandler = new PathHandler(BASE_DIR, TEMP_DIR);
        HbaseManager bdManager = new HbaseManager(configs, connection, admin, dfs);
        HDFSManager dfsManager = new HDFSManager(configs, dfs, pathHandler);

        String action = args[0];
        String instance = args[1];
        String type = args[2];

        List<HBaseProtos.SnapshotDescription> dbSnaps = bdManager.listSnapshots().stream()
                .filter(s -> s.getName().contains(instance) && s.getName()
                .contains(LATEST_DATE)).collect(Collectors.toList());

        Path insPath = new Path(SNAPSHOT_PATH, instance);
        Instance inst = new Instance(instance, LATEST_DATE, dbSnaps, insPath);

        if(action.equals("verify")){
            VerifyService verService = new VerifyService(bdManager, dfsManager);
            Verifier mdVerifier = new MetadataVerifier(verService);
            Verifier rcVerifier = new RowVerifier(verService);
            Verifier flVerifier = new FileVerifier(verService);
            List<VerificationReport> reports = new ArrayList<>();
            VerificationReport report;
            if(type.equals("brief")){
                mdVerifier.setNext(flVerifier);
                report =  mdVerifier.verify(inst);
            }
            else{
                mdVerifier.setNext(rcVerifier);
                rcVerifier.setNext(flVerifier);
                report = mdVerifier.verify(inst);
            }
            reports.add(report);
            ReportHandler dbHandler = new HbaseResultHandler(bdManager, TABLE_NAME);
            ReportHandler cnsHandler = new ConsoleResultHandler();
            dbHandler.setNext(cnsHandler);
            dbHandler.handle(reports);
        }
        else if(action.equals("restore")){

            RestoreService rsService = new RestoreService(bdManager, dfsManager);
//            rsService.run();
        }
        else{
            System.out.println("Wrong action");
        }
    }

}
