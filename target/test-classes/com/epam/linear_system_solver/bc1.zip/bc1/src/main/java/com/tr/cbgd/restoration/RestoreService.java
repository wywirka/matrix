package com.tr.cbgd.restoration;

import com.tr.cbgd.HDFSManager;
import com.tr.cbgd.HbaseManager;
import com.tr.cbgd.Instance;
import lombok.extern.slf4j.Slf4j;

import java.io.IOException;

@Slf4j
public class RestoreService {

    private HbaseManager dbManager;
    private HDFSManager fsManager;

    public RestoreService(HbaseManager dbManager, HDFSManager fsManager) {
        this.dbManager = dbManager;
        this.fsManager = fsManager;
    }


//    public List<HBaseProtos.SnapshotDescription> listSnapshots() throws IOException {
//        return dbManager.listSnapshots();
//    }

    public void restore(Instance ins) throws IOException{
        try {
            dbManager.restore(ins.getDbSnapshots());
//            fsManager.restore(ins.getSnapLocation());
            dbManager.updateTable(ins.getName());
        }catch (IOException e){
            log.error("Restore attempt failed {}", e.getMessage());
            throw new IOException("Restore attempt failed");
        }

    }

    //    public void restore(List<HBaseProtos.SnapshotDescription> snapshots) throws IOException {
//        for(HBaseProtos.SnapshotDescription snap: snapshots){
//            restore(snap);
//        }
//    }
//
//    public void restore(HBaseProtos.SnapshotDescription snapshot) throws IOException{
//        connection.getAdmin().restoreSnapshot(snapshot.getName());
//    }
//
//    public void restore(Path snapshotPath) throws IOException{
//        FileUtil.copy(dfs, snapshotPath, dfs, new Path(""), false, conf);
//    }
}
