package com.tr.cbgd.report;

import com.tr.cbgd.Instance;
import com.tr.cbgd.verification.CheckingResult;

public class VerificationReport {

    private String name;
    @Cell(columnFamily = "info", column="instance")
    private String instance;
    @Cell(columnFamily = "info", column="status")
    private String status;
    @Cell(columnFamily = "info", column="message")
    private String message;

    public VerificationReport() {
    }


    public VerificationReport(String name, String instance, String status) {
        this.name = name;
        this.instance = instance;
        this.status = status;
    }

    public VerificationReport(String name, String instance, String status, String message) {
        this.name = name;
        this.instance = instance;
        this.status = status;
        this.message = message;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getName() {
        return name;
    }

    public String getStatus() {
        return status;
    }

    public String getMessage() {
        return message;
    }


    public static VerificationReport generate(Instance ins, CheckingResult result){
        return  new VerificationReport(ins.getName() +"_"+ ins.getDate(), ins.getName(), result.getStatus(), result.getMessage());

    }

    @Override
    public String toString() {
        return "Report: " +
                "='" + name + '\'' +
                "with status " + status + '\'' +
                ", message='" + message + '\'' +
                ", for instance " + instance + '\'' +
                '}';
    }
}
