package com.tr.cbgd.verification;

import com.tr.cbgd.Instance;
import com.tr.cbgd.report.VerificationReport;

public class FileVerifier extends Verifier {

    private VerifyService verifyService;

    public FileVerifier(VerifyService verifyService) {
        this.verifyService = verifyService;
    }

    @Override
    public VerificationReport verify(Instance ins) {
        CheckingResult checking = verifyService.verify(ins.getSnapLocation());
        if (hasNext() && checking.getStatus().equals("VALID")){
            return next.verify(ins);
        }
        return VerificationReport.generate(ins, checking);
    }

    @Override
    public Verifier setNext(Verifier verifier) {
        return super.setNext(verifier);
    }

    @Override
    public boolean hasNext() {
        return super.hasNext();
    }
}
