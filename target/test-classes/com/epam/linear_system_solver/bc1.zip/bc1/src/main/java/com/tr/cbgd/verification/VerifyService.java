package com.tr.cbgd.verification;

import com.tr.cbgd.HDFSManager;
import com.tr.cbgd.HbaseManager;
import com.tr.cbgd.verification.CheckingResult;
import lombok.extern.slf4j.Slf4j;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.protobuf.generated.HBaseProtos;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Slf4j
public class VerifyService {

    private static final int EXPECTED_SIZE = 2;
    private static final Path ORIGINAL_PATH = new Path("/project/trdev/tr-iryna");
    private HbaseManager dbManager;
    private HDFSManager fsManager;

    public VerifyService(HbaseManager dbManager, HDFSManager fsManager) {
        this.dbManager = dbManager;
        this.fsManager = fsManager;
    }

    public CheckingResult verify(Path snapPath){
        String status;
        String message;
        Path tempPath;
        try{
            tempPath = fsManager.copyToNew(snapPath, fsManager.getTempLocation());
            log.info("Cloned path to temp location {}", fsManager.getTempLocation());
            List<String> difference = fsManager.checkIdentity(ORIGINAL_PATH,tempPath);
            log.info("Non identical file number", difference.size());
            status = difference.isEmpty() ? "VALID"  : "INVALID";
            message = difference.isEmpty() ? "" : difference.toString();
            fsManager.delete(tempPath);
        }catch (IOException e){
            status = "INVALID";
            message = e.getMessage();
        }

        return new CheckingResult(status, message);
    }

        public CheckingResult verify(List<HBaseProtos.SnapshotDescription> dbSnapshots){
        log.info("Snapshot number {}", dbSnapshots.size());
        if (dbSnapshots.size() != EXPECTED_SIZE){
            return new CheckingResult("INVALID", "Number of current snapshots is less than expected");
        }

        try {
            for (HBaseProtos.SnapshotDescription snapshot : dbSnapshots) {
                if (!dbManager.isCorrectSnapshot(snapshot, TableName.valueOf(snapshot.getTable()))) {
                    return new CheckingResult("INVALID", "Snapshot metadata " + snapshot.getName() + " are inconcictent");
                }
            }
        }
        catch(IOException e){
            return new CheckingResult("INVALID", "Issue with HDFS");
        }

        return new CheckingResult("VALID", "");
    }

    public CheckingResult verifyExtended(List<HBaseProtos.SnapshotDescription> dbSnapshots){

        try{
            for (HBaseProtos.SnapshotDescription snapshot : dbSnapshots) {
                TableName originalTable = TableName.valueOf(snapshot.getTable());
                TableName clonedTable = dbManager.clone(snapshot);
                log.info("Cloned table name", clonedTable.getNameAsString());
                long countResult = dbManager.checkRowCount(originalTable, clonedTable,snapshot.getCreationTime()+1L);
                dbManager.delete(clonedTable);
                if (countResult !=0 ) {
                    return new CheckingResult("INVALID", "Rows in snapshot " + snapshot.getName() + " are inconsistent " + countResult);
                }
            }
        }
        catch (IOException e){
            return new CheckingResult("INVALID", "Hbase related issue");
        }


        return new CheckingResult("VALID", "");
    }

//    public List<VerificationReport> verify(List<HBaseProtos.SnapshotDescription> dbSnapshots){
//        List reports = new ArrayList();
//        log.info("Snapshot number {}", dbSnapshots.size());
//        if (dbSnapshots.size() == EXPECTED_SIZE){
//            for (HBaseProtos.SnapshotDescription snapshot: dbSnapshots) {
//                reports.add(verify(snapshot));
//            }
//        }
//        else{
//            for (HBaseProtos.SnapshotDescription snap: dbSnapshots){
//                reports.add(new VerificationReport(snap.getName(), "INVALID", "Number of current snapshots is less than expected"));
//            }
//        }
//        return reports;
//    }

//    public VerificationReport verify(HBaseProtos.SnapshotDescription dbSnap){
//        String status;
//        String message="";
//        TableName originalTable = TableName.valueOf(dbSnap.getTable());
//        log.info("Snapshot origin - {} table", originalTable.getNameAsString());
//        try{
//            boolean isSchemaValid = dbManager.isCorrectSnapshot(dbSnap, originalTable);
//            log.info("isSchemaValid {}", isSchemaValid);
//            if(isSchemaValid){
//                TableName clonedTable = dbManager.clone(dbSnap);
//                log.info("Cloned table name", clonedTable.getNameAsString());
//                long countResult = dbManager.checkRowCount(originalTable, clonedTable,dbSnap.getCreationTime()+1L);
//                dbManager.delete(clonedTable);
//                if(countResult == 0){
//                    status = "VALID";
//                }
//                else{
//                    status = "INVALID";
//                    message = countResult>0 ? originalTable.getNameAsString(): clonedTable.getNameAsString() +"has "+ Math.abs(countResult) + "more records";
//                }
//            }
//            else {
//                status = "INVALID";
//                message = "Snapshot is corrupted";
//            }
//
//        }
//        catch(IOException e){
//            status = "UNKNOWN";
//            message = e.getMessage();
//        }
//        return new VerificationReport(dbSnap.getName(), status, message);
//    }


}
