package com.tr.cbgd.verification;

import com.tr.cbgd.Instance;
import com.tr.cbgd.report.VerificationReport;

public abstract class Verifier {
    protected Verifier next;

    public abstract VerificationReport verify(Instance ins);
//    public abstract void handle(com.tr.cbgd.report.VerificationReport report);


    public Verifier setNext(Verifier verifier){
        this.next = verifier;
        return next;

    }

    public boolean hasNext(){
        return next != null;
    }

}
