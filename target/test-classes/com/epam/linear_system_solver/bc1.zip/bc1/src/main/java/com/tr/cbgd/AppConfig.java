package com.tr.cbgd;

import lombok.extern.slf4j.Slf4j;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hbase.HBaseConfiguration;

@Slf4j
public class AppConfig {

    public static Path HBASE_SITE = new Path("C:\\ProgramFiles\\hbase-1.6.0\\conf\\hbase-site.xml");
    public static Path CORE_SITE = new Path("C:\\ProgramFiles\\hadoop-2.9.2\\etc\\hadoop\\core-site.xml");
    public static Path HDFS_SITE = new Path("C:\\ProgramFiles\\hadoop-2.9.2\\etc\\hadoop\\hdfs-site.xml");

    public static Configuration getConfig(){
        Configuration config = HBaseConfiguration.create();
        config.addResource(HBASE_SITE);
        config.addResource(CORE_SITE);
        config.addResource(HDFS_SITE);
        log.info("Xml sites have been added to configs");
        return config;
    }
}
